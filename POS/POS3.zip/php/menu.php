<?php
require_once '../includes/auth.php';
require_once '../includes/permissions.php';
require_once '../includes/icons.php';
require_login();
require_clocked_in_for_pos();
require_permission('orders.new');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Point of Sale — BrewVanti POS</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,600;0,700;1,600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../css/style.css?v=<?= filemtime(__DIR__.'/../css/style.css') ?>">
  <link rel="stylesheet" href="../css/sidebar.css?v=<?= filemtime(__DIR__.'/../css/sidebar.css') ?>">
  <link rel="stylesheet" href="../css/menu.css?v=<?= filemtime(__DIR__.'/../css/menu.css') ?>">
  <link rel="stylesheet" href="../css/order-panel.css?v=<?= filemtime(__DIR__.'/../css/order-panel.css') ?>">
  <link rel="stylesheet" href="../css/receipt_modal.css?v=<?= filemtime(__DIR__.'/../css/receipt_modal.css') ?>">
</head>
<body>

<?php include("../includes/sidebar.php"); ?>

<div id="page-menu" class="page active">

    <!-- Ambient Dark Luxury Glow & Floating 2.5D Beans -->
    <div class="pos-ambient-bg"></div>
    <svg aria-hidden="true" class="floating-bean bean-1" viewBox="0 0 50 70" fill="none">
      <ellipse cx="25" cy="35" rx="20" ry="30" fill="#38251C" stroke="#D9BA85" stroke-width="1.5"/>
      <path d="M25,8 Q33,35 25,62" stroke="#D9BA85" stroke-width="2" stroke-linecap="round"/>
    </svg>
    <svg aria-hidden="true" class="floating-bean bean-2" viewBox="0 0 50 70" fill="none">
      <ellipse cx="25" cy="35" rx="20" ry="30" fill="#281A14" stroke="#D9BA85" stroke-width="1.2"/>
      <path d="M25,10 Q18,35 25,60" stroke="#D9BA85" stroke-width="1.8" stroke-linecap="round"/>
    </svg>
    <svg aria-hidden="true" class="floating-bean bean-3" viewBox="0 0 50 70" fill="none">
      <ellipse cx="25" cy="35" rx="22" ry="32" fill="#1C120D" stroke="#D9BA85" stroke-width="1"/>
      <path d="M25,7 Q32,35 25,63" stroke="#D9BA85" stroke-width="2"/>
    </svg>

    <!-- Mobile Drawer Backdrop for phone / tablet -->
    <div class="mobile-cart-backdrop" id="mobile-cart-backdrop" onclick="closeMobileCart()"></div>

    <div class="menu-left">
      <!-- Executive POS Header matching reference design -->
      <div class="pos-page-head">
        <div class="pos-head-title-wrap">
          <div class="hero-badge-chip">✦ Fresh Brew, Warm Moments</div>
          <h1 class="pos-title">Point of Sale <span class="gold-script">Terminal</span></h1>
          <p class="pos-description">Choose a size, add drinks, then review the order.</p>
        </div>

        <div class="pos-head-actions">
          <div class="menu-search">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
            <input type="search" id="menu-search" aria-label="Search drinks in all categories" placeholder="Search all drinks…" oninput="filterProducts(this.value)">
          </div>
          <div class="pos-shift-badge">
            <span class="pos-pulse-ring"></span>
            <span class="pos-shift-text">Ready for orders</span>
          </div>
        </div>
      </div>

      <!-- POS Process Workflow Card (Inspired by reference design) -->

      <div class="catalog-controls-bar">
        <div class="category-tabs" role="group" aria-label="Drink category">
          <button type="button" class="cat-tab active" aria-pressed="true" onclick="switchCat(this,'all')">
            <?= icon('dashboard', 14) ?>
            <span>All Drinks</span>
          </button>
          <button type="button" class="cat-tab" aria-pressed="false" onclick="switchCat(this,'ice-coffee')">
            <?= icon('ice-coffee', 14) ?>
            <span>Iced Coffee</span>
          </button>
          <button type="button" class="cat-tab" aria-pressed="false" onclick="switchCat(this,'hot-coffee')">
            <?= icon('coffee', 14) ?>
            <span>Hot Coffee</span>
          </button>
          <button type="button" class="cat-tab" aria-pressed="false" onclick="switchCat(this,'milk-tea')">
            <?= icon('cup-tea', 14) ?>
            <span>Milk Tea</span>
          </button>
          <button type="button" class="cat-tab" aria-pressed="false" onclick="switchCat(this,'fruit-tea')">
            <?= icon('fruit', 14) ?>
            <span>Fruit Tea</span>
          </button>
        </div>

        <div class="size-bar" role="group" aria-label="Drink size">
          <button type="button" class="size-btn active" aria-pressed="true" onclick="switchSize(this,'small')">
            <span>Regular</span> <small>(16oz)</small>
          </button>
          <button type="button" class="size-btn" aria-pressed="false" onclick="switchSize(this,'large')">
            <span>Large</span> <small>(22oz)</small>
          </button>
        </div>
      </div>

      <div class="pos-catalog-summary">
        <p id="catalog-status" role="status" aria-live="polite">Loading drinks…</p>
        <button type="button" class="pos-reset-search" id="reset-menu-search" onclick="resetProductSearch()" hidden>Clear search</button>
      </div>
      <div class="menu-grid-wrap" aria-label="Drink catalog">
        <div id="menu-grid" class="menu-grid" aria-busy="true"></div>
      </div>
    </div>

    <!-- Order Panel (Right side on Desktop, Bottom Sheet Drawer on Mobile) -->
    <section class="order-panel" id="order-panel" aria-label="Current order">
      <div class="order-panel-heading"><h2>Current order</h2><span id="desktop-ticket-count">0 items</span></div>
      <!-- Mobile Drawer Handle & Header (Visible only on mobile/tablet) -->
      <div class="order-panel-mobile-bar">
        <div class="op-drag-handle"></div>
        <div class="op-mobile-head">
          <div class="op-mobile-title">
            <strong>Current order</strong>
            <span class="op-mobile-count" id="mobile-ticket-count">0 items</span>
          </div>
          <button type="button" class="op-mobile-close-btn" onclick="closeMobileCart()">
            <?= icon('x', 16) ?> <span>Close</span>
          </button>
        </div>
      </div>

      <div class="order-type-bar" role="group" aria-label="Order type">
        <button class="order-type-btn active" aria-pressed="true" onclick="switchOrderType(this,'dine')">
          <?= icon('utensils', 15) ?>
          <span>Dine In</span>
        </button>
        <button class="order-type-btn" aria-pressed="false" onclick="switchOrderType(this,'take')">
          <?= icon('shopping-bag', 15) ?>
          <span>Take Out</span>
        </button>
      </div>

      <div id="order-items" class="order-items">
        <div class="order-empty">
          <div class="oe-icon"><img src="../assets/milktea.png" alt="" style="width:48px;height:48px;opacity:0.6;margin-bottom:8px;display:block;margin-left:auto;margin-right:auto;"/></div>
          <p>No items yet</p>
          <small>Tap a drink to add it</small>
        </div>
      </div>

      <div class="order-footer">
        <div class="order-row"><span>Subtotal (VAT-ex)</span><span id="subtotal">₱0.00</span></div>
        <div class="order-row"><span>VAT (12%)</span><span id="tax">₱0.00</span></div>
        <div class="order-row total"><strong>Total</strong><strong id="total">₱0.00</strong></div>
        <button class="checkout-btn" id="review-order-btn" onclick="checkout()" disabled><?= icon('credit-card', 16) ?> Review &amp; pay</button>
        <button class="clear-btn" id="clear-order-btn" onclick="clearOrder()" disabled><?= icon('trash', 14) ?> Clear order</button>
      </div>
    </section>

    <!-- Sticky Mobile Cart Bar for Phones & Tablets -->
    <div class="mobile-cart-bar" id="mobile-cart-bar" inert>
      <div class="mcb-left">
        <div class="mcb-icon-wrap">
          <?= icon('cart', 20) ?>
          <span class="mcb-badge" id="mcb-count">0</span>
        </div>
        <div class="mcb-text">
          <span class="mcb-label">Order Total</span>
          <strong class="mcb-total" id="mcb-total">₱0.00</strong>
        </div>
      </div>
      <button type="button" class="mcb-btn" id="mobile-cart-toggle" onclick="openMobileCart()" aria-controls="order-panel" aria-expanded="false">
        <span>View order</span>
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
      </button>
    </div>

  </div>

<!-- Receipt Modal -->
<div class="modal-overlay" id="receipt-overlay">
  <div class="receipt-modal">

    <div class="receipt-head">
      <div class="receipt-check"><?= icon('check', 24) ?></div>
      <h2>Order Placed!</h2>
      <p>Your order has been sent to the kitchen</p>
      <span class="receipt-order-num" id="r-order-num">#0001</span>
    </div>

    <div class="receipt-body">
      <div class="receipt-meta">
        <span id="r-type">Dine In</span>
        <span>Order time: <time id="r-time"></time></span>
      </div>

      <div class="receipt-items" id="r-items"></div>

      <div class="receipt-totals">
        <div class="rt-row"><span>Subtotal (VAT-ex)</span><span id="r-subtotal">₱0.00</span></div>
        <div class="rt-row"><span>VAT (12%)</span><span id="r-tax">₱0.00</span></div>
        <div class="rt-row grand"><span>Total</span><span id="r-total">₱0.00</span></div>
        <div class="rt-divider"></div>
        <div class="rt-row" id="r-row-payment"><span>Payment Method</span><span id="r-payment-method">Cash</span></div>
        <div class="rt-row" id="r-row-tendered"><span>Cash Tendered</span><span id="r-tendered">₱0.00</span></div>
        <div class="rt-row" id="r-row-change"><span>Change</span><span id="r-change">₱0.00</span></div>
        <div class="rt-row" id="r-row-ref" style="display:none;"><span>Reference / ID</span><span id="r-ref" class="r-ref-code">-</span></div>
      </div>
    </div>

    <div class="receipt-footer">
      <button class="btn-print" onclick="printReceipt()"><?= icon('printer', 14) ?> Print</button>
      <button class="btn-new-order" onclick="closeReceipt()"><?= icon('plus', 14) ?> New Order</button>
    </div>

  </div>
</div>

<!-- Payment & Confirm Modal -->
<div class="modal-overlay" id="confirm-overlay">
  <div class="receipt-modal payment-modal">
    <div class="receipt-head payment-modal-head">
      <div class="receipt-check" style="background:var(--caramel);"><?= icon('credit-card', 22) ?></div>
      <h2>Payment & Confirmation</h2>
      <p>Review items and select payment method</p>
    </div>

    <div class="receipt-body payment-modal-body">
      <div class="checkout-summary-card">
        <div class="csc-left">
          <span class="csc-type" id="confirm-type">Dine In</span>
          <span class="csc-count" id="confirm-count">0 items</span>
        </div>
        <div class="csc-right">
          <span class="csc-label">Total to Pay</span>
          <span class="csc-total" id="confirm-total">₱0.00</span>
        </div>
      </div>

      <details class="checkout-items-toggle">
        <summary><span><?= icon('menu-lines', 13) ?> View Order Items</span></summary>
        <div id="confirm-items-list" class="checkout-items-dropdown"></div>
      </details>

      <div class="pm-section-title">Select Payment Method</div>
      <div class="payment-methods-grid">
        <button type="button" class="pay-method-card active" data-method="cash" onclick="selectPaymentMethod('cash')">
          <span class="pmc-icon"><?= icon('coin', 18) ?></span>
          <span class="pmc-name">Cash</span>
          <span class="pmc-desc">Cash & Change</span>
        </button>

        <button type="button" class="pay-method-card" data-method="paymongo" onclick="selectPaymentMethod('paymongo')">
          <span class="pmc-icon"><?= icon('qr', 18) ?></span>
          <span class="pmc-name">PayMongo QR</span>
          <span class="pmc-desc">GCash / Maya / QR Ph / Card</span>
        </button>

        <button type="button" class="pay-method-card" data-method="ewallet" onclick="selectPaymentMethod('ewallet')">
          <span class="pmc-icon"><?= icon('smartphone', 18) ?></span>
          <span class="pmc-name">Manual E-Wallet</span>
          <span class="pmc-desc">OTC GCash / Maya</span>
        </button>

        <button type="button" class="pay-method-card" data-method="card" onclick="selectPaymentMethod('card')">
          <span class="pmc-icon"><?= icon('card', 18) ?></span>
          <span class="pmc-name">Card Terminal</span>
          <span class="pmc-desc">POS Slip Approval</span>
        </button>
      </div>

      <!-- Detail Panels per Method -->
      <!-- 1. CASH -->
      <div id="pm-panel-cash" class="pm-panel active">
        <label class="pm-label" for="cash-tendered">Cash Tendered (₱)</label>
        <div class="tendered-input-wrap">
          <span class="t-prefix">₱</span>
          <input type="number" step="any" min="0" id="cash-tendered" placeholder="0.00" oninput="onTenderedInput(this.value)">
          <button type="button" class="btn-clear-t" onclick="clearTendered()" title="Clear">✕</button>
        </div>

        <div class="quick-bills-bar">
          <button type="button" class="quick-bill-pill exact" onclick="applyQuickBill('exact')">Exact</button>
          <button type="button" class="quick-bill-pill" onclick="applyQuickBill(100)">₱100</button>
          <button type="button" class="quick-bill-pill" onclick="applyQuickBill(200)">₱200</button>
          <button type="button" class="quick-bill-pill" onclick="applyQuickBill(500)">₱500</button>
          <button type="button" class="quick-bill-pill" onclick="applyQuickBill(1000)">₱1,000</button>
        </div>

        <div class="change-display-card" id="change-display-card">
          <div class="cdc-header">
            <span class="cdc-title">Change Due:</span>
            <span class="cdc-amount" id="cash-change">₱0.00</span>
          </div>
          <div class="cdc-note" id="cash-change-msg">Enter amount received from customer</div>
        </div>
      </div>

      <!-- 2. PAYMONGO -->
      <div id="pm-panel-paymongo" class="pm-panel">
        <div class="paymongo-box">
          <div id="pm-init-box" class="pm-init-state">
            <div class="pm-init-icon"><?= icon('qr', 36) ?></div>
            <h4>Dynamic PayMongo QR</h4>
            <p>Generate a secure PayMongo checkout session supporting GCash, Maya, QR Ph, GrabPay, and credit/debit cards.</p>
            <button type="button" class="btn-pm-generate" onclick="startPayMongoSession()">
              <?= icon('zap', 14) ?> Generate QR & Checkout
            </button>
          </div>

          <div id="pm-live-box" class="pm-live-state" style="display:none;">
            <div class="pm-qr-frame">
              <img id="pm-qr-img" src="" alt="Scan QR Code" />
              <div class="pm-qr-spinner-badge">
                <span class="pm-pulse-dot"></span> Waiting for payment...
              </div>
            </div>
            <div class="pm-live-details">
              <div class="pm-status-line" id="pm-status-text">Awaiting customer payment confirmation...</div>
              <div class="pm-actions-line">
                <a href="#" target="_blank" id="pm-ext-link" class="pm-btn-secondary">
                  <?= icon('external-link', 13) ?> Open Customer Checkout Screen
                </a>
                <button type="button" class="pm-btn-secondary" onclick="checkPayMongoStatusManual()">
                  <?= icon('refresh', 13) ?> Check Now
                </button>
              </div>
              <div id="pm-demo-actions" style="display:none; margin-top:8px;">
                <button type="button" class="pm-btn-simulate" onclick="simulatePayMongoPayment()">
                  <?= icon('shield-check', 13) ?> Simulate Customer Paid (Dev / Demo)
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 3. DIRECT E-WALLET -->
      <div id="pm-panel-ewallet" class="pm-panel">
        <div class="provider-pill-selector">
          <label class="provider-pill">
            <input type="radio" name="ewallet_vendor" value="GCash" checked onchange="setWalletVendor('GCash')">
            <span>GCash OTC</span>
          </label>
          <label class="provider-pill">
            <input type="radio" name="ewallet_vendor" value="Maya" onchange="setWalletVendor('Maya')">
            <span>Maya OTC</span>
          </label>
        </div>
        <label class="pm-label" for="ewallet-ref">Transaction / Reference Number <span style="color:#d9534f">*</span></label>
        <input type="text" id="ewallet-ref" class="pm-text-field" placeholder="Enter reference number (e.g. 1029384756)" maxlength="50">
        <div class="pm-field-hint">Customer scans your store QR code or sends payment directly. Enter the reference number here.</div>
      </div>

      <!-- 4. CARD TERMINAL -->
      <div id="pm-panel-card" class="pm-panel">
        <label class="pm-label" for="card-approval">Terminal Approval / Trace Number <span style="color:#d9534f">*</span></label>
        <input type="text" id="card-approval" class="pm-text-field" placeholder="Enter approval code (e.g. APP-9481)" maxlength="50">
        <div class="pm-field-hint">Swipe / tap customer card on physical terminal and input the approval code from the terminal printout.</div>
      </div>

    </div>

    <div class="receipt-footer payment-modal-footer">
      <button class="btn-print" onclick="closeConfirmOrder()">Cancel</button>
      <button class="btn-new-order" id="confirm-order-btn" onclick="submitConfirmedOrder()"><?= icon('check', 14) ?> Confirm & Complete</button>
    </div>
  </div>
</div>

<!-- No Items Modal -->
<div class="modal-overlay" id="noitems-overlay">
  <div class="receipt-modal" style="max-width:340px">
    <div class="receipt-head" style="padding:24px 24px 18px">
      <div class="receipt-check" style="background:#d4a056"><?= icon('alert-triangle', 24) ?></div>
      <h2>No Items!</h2>
      <p>Please add items first.</p>
    </div>
    <div class="receipt-footer" style="padding:0 24px 22px">
      <button class="btn-new-order" style="flex:1" onclick="closeNoItems()">OK</button>
    </div>
  </div>
</div>

<!-- SweetAlert2 first, then menu.js -->
<script src="../assets/vendor/sweetalert2/sweetalert2.all.min.js"></script>
<script src="../js/menu.js?v=<?= filemtime(__DIR__.'/../js/menu.js') ?>"></script>

</body>
</html>
