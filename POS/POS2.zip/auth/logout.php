<?php
// logout.php - Logout Handler
require_once __DIR__ . '/../includes/security.php';
secure_session_start();

$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
session_destroy();

header('Location: ../index.html?reason=logout', true, 303);
exit;
