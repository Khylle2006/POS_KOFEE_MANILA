<?php
require_once '../includes/auth.php';
require_once '../includes/permissions.php';

require_login();
// Employee Dashboard is the employee personal self-service portal (clock-in/out, shifts, payslips, leave).
// Any authenticated staff member has access to their own dashboard.


$pdo   = get_db();
$user  = current_user();
$today = date('Y-m-d');
$clock_in_required = ($_GET['reason'] ?? '') === 'clock_in_required';

const ANNUAL_LEAVE_DAYS = 15; // placeholder pool — adjust to your real policy
$leave_types = ['Vacation','Sick','Emergency','Unpaid','Other'];

$stmt = $pdo->prepare('SELECT * FROM employees WHERE user_id = :uid LIMIT 1');
$stmt->execute([':uid' => $user['id']]);
$my_employee = $stmt->fetch() ?: null;
if (!$my_employee) {
    $my_employee = get_or_create_user_employee($pdo, (int)$user['id']);
}

// ── Today's attendance row ─────────────────────
$today_att = null;
if ($my_employee) {
    $s = $pdo->prepare('SELECT * FROM attendance WHERE employee_id=:e AND attendance_date=:d');
    $s->execute([':e'=>$my_employee['id'], ':d'=>$today]);
    $today_att = $s->fetch() ?: null;
}

// ── This month's metrics ───────────────────────
$metrics = ['present'=>0, 'absent'=>0, 'work_days'=>0, 'leave_balance'=>ANNUAL_LEAVE_DAYS];
if ($my_employee) {
    $month_start = date('Y-m-01');
    $month_end   = date('Y-m-t');

    $st = $pdo->prepare("
        SELECT status, COUNT(*) c FROM attendance
        WHERE employee_id=:e AND attendance_date BETWEEN :s AND :en
        GROUP BY status
    ");
    $st->execute([':e'=>$my_employee['id'], ':s'=>$month_start, ':en'=>$month_end]);
    $byStatus = [];
    foreach ($st->fetchAll() as $row) $byStatus[$row['status']] = (int)$row['c'];

    $metrics['present']   = ($byStatus['present'] ?? 0) + ($byStatus['late'] ?? 0) + ($byStatus['half_day'] ?? 0);
    $metrics['absent']    = $byStatus['absent'] ?? 0;
    $metrics['work_days'] = array_sum($byStatus);

    $used = $pdo->prepare("
        SELECT COALESCE(SUM(days_count),0) FROM leave_requests
        WHERE employee_id=:e AND status='approved' AND YEAR(start_date)=YEAR(CURDATE())
    ");
    $used->execute([':e'=>$my_employee['id']]);
    $metrics['leave_balance'] = max(0, ANNUAL_LEAVE_DAYS - (float)$used->fetchColumn());
}

// ── Recent attendance (last 10) ────────────────
$att_rows = [];
if ($my_employee) {
    $ar = $pdo->prepare('SELECT * FROM attendance WHERE employee_id=:e ORDER BY attendance_date DESC LIMIT 10');
    $ar->execute([':e'=>$my_employee['id']]);
    $att_rows = $ar->fetchAll();
}

// ── My leave requests (last 8) ─────────────────
$leaves = [];
if ($my_employee) {
    $lr = $pdo->prepare("
        SELECT * FROM leave_requests WHERE employee_id=:e
        ORDER BY FIELD(status,'pending','approved','rejected'), created_at DESC LIMIT 8
    ");
    $lr->execute([':e'=>$my_employee['id']]);
    $leaves = $lr->fetchAll();
}

$hour = (int)date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');
$fname = $user['firstname'] ?: $user['username'];
$initials = strtoupper(substr($fname, 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>My Dashboard — Kofee Manila</title>
  <link rel="stylesheet" href="../css/style.css"/>
  <link rel="stylesheet" href="../css/home.css"/>
  <link rel="stylesheet" href="../css/employee_dashboard.css"/>
  <link rel="stylesheet" href="../css/index.css">
  <link rel="stylesheet" href="../css/sidebar.css?v=<?= filemtime(__DIR__ . '/../css/sidebar.css') ?>"/>
  <style>
    .item-row { display:grid; grid-template-columns:minmax(0,2fr) 90px 70px 120px 32px; gap:8px; margin-bottom:8px; align-items:center; }
    .item-row input, .item-row select { min-width:0; width:100%; }
    .item-row .rm-item { background:var(--red-lt); color:var(--red); border:none; border-radius:8px; width:32px; height:32px; flex-shrink:0; cursor:pointer; }
    @media (max-width:560px) {
      .item-row { grid-template-columns:minmax(0,1fr) 80px 32px; }
      .item-row .item-select { grid-column:1 / -1; }
      .item-row .qty { grid-column:1 / 2; grid-row:2; }
      .item-row .unit { grid-column:2 / 3; grid-row:2; }
      .item-row .price { grid-column:1 / 3; grid-row:3; }
      .item-row .rm-item { grid-column:3 / 4; grid-row:2; }
    }
  </style>
</head>
<body>
<?php include("../includes/sidebar.php"); ?>

<div id="page-employee-home" class="page active">
  <div class="page-header">
    <div>
      <h1><?= $greeting ?>, <?= htmlspecialchars($fname) ?> <?= icon('sun', 20) ?></h1>
      <p><?= date('l, F j, Y') ?> — Your attendance &amp; leave overview</p>
    </div>
    <div class="signed-in-pill">
      Signed in as <b>@<?= htmlspecialchars($user['username']) ?></b>
      <div class="signed-in-avatar"><?= htmlspecialchars($initials) ?></div>
    </div>
  </div>

  <div class="page-body">

    <?php if ($clock_in_required): ?>
      <div class="notice-banner" style="background:var(--amber-lt);color:var(--amber);border-color:#f2ddb8">
        Please clock in before accessing the POS system.
      </div>
    <?php endif; ?>

    <?php if (!$my_employee): ?>
      <div class="notice-banner">
        Your account isn't linked to an employee profile yet, so clock in/out and leave filing are disabled. Ask HR to link your account.
      </div>
    <?php endif; ?>

    <!-- Stat cards -->
    <div class="home-grid">
      <div class="stat-card">
        <div class="stat-card-top">
          <div class="stat-icon stat-icon-status"><?= icon('attendance', 20) ?></div>
          <span class="stat-badge-tag">Shift</span>
        </div>
        <div class="stat-label">Today's Status</div>
        <div class="stat-value-wrap" id="today-status-val">
          <?php if ($today_att && $today_att['time_in'] && !$today_att['time_out']): ?>
            <span class="status-pill status-pill-in"><span class="status-pulse"></span>Clocked In</span>
          <?php elseif ($today_att && $today_att['time_out']): ?>
            <span class="status-pill status-pill-out"><span class="status-dot"></span>Clocked Out</span>
          <?php else: ?>
            <span class="status-pill status-pill-none"><span class="status-dot"></span>Not Clocked In</span>
          <?php endif; ?>
        </div>
        <div class="stat-sub" id="today-status-sub">
          <?= $today_att && $today_att['time_in'] ? date('g:i A', strtotime($today_att['time_in'])) : 'Tap Clock In to start' ?>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-card-top">
          <div class="stat-icon stat-icon-green"><?= icon('order', 20) ?></div>
          <span class="stat-badge-tag tag-green">Attendance</span>
        </div>
        <div class="stat-label">Present Days</div>
        <div class="stat-value"><?= $metrics['present'] ?></div>
        <div class="stat-sub">This month</div>
      </div>
      <div class="stat-card">
        <div class="stat-card-top">
          <div class="stat-icon stat-icon-red"><?= icon('pending', 20) ?></div>
          <span class="stat-badge-tag tag-red">Missed</span>
        </div>
        <div class="stat-label">Absent Days</div>
        <div class="stat-value"><?= $metrics['absent'] ?></div>
        <div class="stat-sub">This month</div>
      </div>
      <div class="stat-card">
        <div class="stat-card-top">
          <div class="stat-icon stat-icon-blue"><?= icon('leave', 20) ?></div>
          <span class="stat-badge-tag tag-blue">Allowance</span>
        </div>
        <div class="stat-label">Leave Balance</div>
        <div class="stat-value"><?= $metrics['leave_balance'] ?></div>
        <div class="stat-sub">Days remaining</div>
      </div>
    </div>

    <!-- Quick access -->
    <div class="shortcuts-section">
      <div class="section-title">
        <span>Quick Access</span>
        <span class="section-subtitle">Common daily actions</span>
      </div>
      <div class="home-shortcuts">
        <button type="button" class="shortcut-card shortcut-clockin" id="btn-clockin"
                onclick="openCamera('clock_in')" <?= (!$my_employee || ($today_att && $today_att['time_in'])) ? 'disabled' : '' ?>>
          <div class="shortcut-icon"><?= icon('attendance', 22) ?></div>
          <div class="shortcut-meta">
            <h3>Clock In</h3>
            <p>Snap a photo to start your shift</p>
          </div>
          <div class="shortcut-arrow"><?= icon('chevron', 16) ?></div>
        </button>
        <button type="button" class="shortcut-card shortcut-clockout" id="btn-clockout"
                onclick="openCamera('clock_out')" <?= (!$my_employee || !$today_att || !$today_att['time_in'] || $today_att['time_out']) ? 'disabled' : '' ?>>
          <div class="shortcut-icon"><?= icon('attendance', 22) ?></div>
          <div class="shortcut-meta">
            <h3>Clock Out</h3>
            <p>Snap a photo to end your shift</p>
          </div>
          <div class="shortcut-arrow"><?= icon('chevron', 16) ?></div>
        </button>
        <button type="button" class="shortcut-card shortcut-leave" onclick="openLeaveModal()" <?= !$my_employee ? 'disabled' : '' ?>>
          <div class="shortcut-icon"><?= icon('leave', 22) ?></div>
          <div class="shortcut-meta">
            <h3>File Leave Request</h3>
            <p>Submit a new leave application</p>
          </div>
          <div class="shortcut-arrow"><?= icon('chevron', 16) ?></div>
        </button>

        <button type="button" class="shortcut-card shortcut-requisition" onclick="openCreate()">
          <div class="shortcut-icon"><?= icon('rfq', 22) ?></div>
          <div class="shortcut-meta">
            <h3>File Requisition</h3>
            <p>Submit a purchase requisition</p>
          </div>
          <div class="shortcut-arrow"><?= icon('chevron', 16) ?></div>
        </button>
      </div>
    </div>

    <!-- Attendance table -->
    <div class="recent-section">
      <div class="recent-header">
        <div class="recent-header-title">
          <h2>My Attendance</h2>
          <span class="recent-count-badge"><?= count($att_rows) ?> records</span>
        </div>
      </div>
      <div class="table-scroll-wrapper">
        <table class="recent-table" id="attendance-table">
          <thead>
            <tr><th>Date</th><th>Time In</th><th>Time Out</th><th>Status</th><th>Proof</th></tr>
          </thead>
          <tbody id="attendance-tbody">
            <?php if (empty($att_rows)): ?>
              <tr class="empty-row"><td colspan="5">No attendance records yet.</td></tr>
            <?php else: foreach ($att_rows as $r): ?>
              <tr>
                <td><?= date('M d, Y', strtotime($r['attendance_date'])) ?></td>
                <td><?= $r['time_in']  ? date('g:i A', strtotime($r['time_in']))  : '—' ?></td>
                <td><?= $r['time_out'] ? date('g:i A', strtotime($r['time_out'])) : '—' ?></td>
                <td><span class="status-badge status-<?= $r['status'] ?>"><?= ucwords(str_replace('_',' ',$r['status'])) ?></span></td>
                <td>
                  <div class="proof-thumbs">
                    <?php if ($r['time_in_photo']): ?>
                      <img src="../<?= htmlspecialchars($r['time_in_photo']) ?>" class="proof-thumb" onclick="openPhotoPreview('../<?= htmlspecialchars($r['time_in_photo']) ?>')" title="Clock-in photo" onerror="this.style.display='none'"/>
                    <?php endif; ?>
                    <?php if ($r['time_out_photo']): ?>
                      <img src="../<?= htmlspecialchars($r['time_out_photo']) ?>" class="proof-thumb" onclick="openPhotoPreview('../<?= htmlspecialchars($r['time_out_photo']) ?>')" title="Clock-out photo" onerror="this.style.display='none'"/>
                    <?php endif; ?>
                    <?php if (!$r['time_in_photo'] && !$r['time_out_photo']): ?>—<?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Leave requests list -->
    <div class="recent-section">
      <div class="recent-header">
        <div class="recent-header-title">
          <h2>My Leave Requests</h2>
          <span class="recent-count-badge"><?= count($leaves) ?> requests</span>
        </div>
      </div>
      <div class="table-scroll-wrapper">
        <table class="recent-table" id="leave-table">
          <thead><tr><th>Type</th><th>Dates</th><th>Days</th><th>Reason</th><th>Status</th></tr></thead>
          <tbody id="leave-tbody">
            <?php if (empty($leaves)): ?>
              <tr class="empty-row"><td colspan="5">No leave requests yet.</td></tr>
            <?php else: foreach ($leaves as $l): ?>
              <tr>
                <td style="font-weight:700"><?= htmlspecialchars($l['leave_type']) ?></td>
                <td><?= date('M d', strtotime($l['start_date'])) ?> – <?= date('M d, Y', strtotime($l['end_date'])) ?></td>
                <td><?= $l['days_count'] ?></td>
                <td class="muted-cell" style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($l['reason'] ?: '—') ?></td>
                <td><span class="status-badge status-<?= $l['status'] ?>"><?= ucfirst($l['status']) ?></span></td>
              </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</div>

<!-- ── Camera / Attendance Modal ── -->
<div class="modal-overlay" id="camera-modal">
  <div class="modal camera-modal">
    <div class="modal-header">
      <h3 id="camera-title">Clock In</h3>
      <button class="modal-close" onclick="closeCamera()"><?= icon('x', 14) ?></button>
    </div>
    <div class="modal-body">
      <div class="camera-frame">
        <video id="camera-video" autoplay playsinline></video>
        <canvas id="camera-canvas" style="display:none"></canvas>
        <img id="camera-preview" style="display:none"/>
      </div>
      <p class="camera-hint" id="camera-hint">Position yourself in frame, then capture.</p>
      <p class="camera-error" id="camera-error" style="display:none"></p>
    </div>
    <div class="modal-actions">
      <button type="button" class="btn-mcancel" onclick="closeCamera()">Cancel</button>
      <button type="button" class="btn-mcancel" id="camera-fallback-btn" style="display:none;margin-right:auto;background:var(--accent-lt);color:var(--caramel);border-color:var(--caramel)" onclick="quickClockWithoutPhoto()">Clock In Without Photo</button>
      <button type="button" class="btn-msave" id="camera-capture-btn" onclick="capturePhoto()"><?= icon('camera', 14) ?> Capture</button>
      <button type="button" class="btn-msave" id="camera-confirm-btn" style="display:none;background:var(--green)" onclick="confirmCapture()"><?= icon('check', 14) ?> Confirm &amp; Submit</button>
      <button type="button" class="btn-mcancel" id="camera-retake-btn" style="display:none" onclick="retakePhoto()"><?= icon('refresh', 14) ?> Retake</button>
    </div>
  </div>
</div>

<!-- ── Photo Preview Modal ── -->
<div class="modal-overlay" id="photo-preview-modal">
  <div class="modal" style="max-width:420px">
    <div class="modal-header">
      <h3>Attendance Proof</h3>
      <button class="modal-close" onclick="closePhotoPreview()"><?= icon('x', 14) ?></button>
    </div>
    <div class="modal-body" style="text-align:center">
      <img id="photo-preview-img" style="max-width:100%;border-radius:10px"/>
    </div>
  </div>
</div>

<!-- ── Requisition Modal ── -->
<div class="modal-overlay" id="create-modal">
  <div class="modal" style="max-width:520px">
    <div class="modal-header">
      <h3>File Purchase Requisition</h3>
      <button class="modal-close" onclick="closeCreate()"><?= icon('x', 14) ?></button>
    </div>
    <form method="POST" action="../php/requisitions.php" id="create-form">
      <input type="hidden" name="action" value="create"/>
      <input type="hidden" name="items" id="items-json"/>
      <div class="modal-body">
        <div id="create-form-error" style="display:none;margin:0 0 12px;padding:10px 14px;border-radius:var(--radius-sm);background:var(--red-lt);color:var(--red);font-size:12.5px;font-weight:600"></div>
        <div class="field-group">
          <label class="field-label">Title <span style="color:var(--red)">*</span></label>
          <input class="field-input" type="text" name="title" id="f-title" placeholder="e.g. Q3 espresso machine parts" required/>
        </div>
        <div class="field-group">
          <label class="field-label">Department</label>
          <select class="field-input" name="department">
            <option value="crew" <?= ($employee['department'] ?? '') === 'crew' ? 'selected' : '' ?>>Crew / Barista</option>
            <option value="cashier" <?= ($employee['department'] ?? '') === 'cashier' ? 'selected' : '' ?>>Cashier</option>
            <option value="ops" <?= ($employee['department'] ?? '') === 'ops' ? 'selected' : '' ?>>Operations</option>
            <option value="manager" <?= ($employee['department'] ?? '') === 'manager' ? 'selected' : '' ?>>Store Management</option>
            <option value="finance" <?= ($employee['department'] ?? '') === 'finance' ? 'selected' : '' ?>>Finance &amp; Accounting</option>
            <option value="hr" <?= ($employee['department'] ?? '') === 'hr' ? 'selected' : '' ?>>Human Resources</option>
            <option value="procurement" <?= ($employee['department'] ?? '') === 'procurement' ? 'selected' : '' ?>>Procurement</option>
            <option value="warehouse" <?= ($employee['department'] ?? '') === 'warehouse' ? 'selected' : '' ?>>Warehouse &amp; Receiving</option>
            <option value="admin" <?= ($employee['department'] ?? '') === 'admin' ? 'selected' : '' ?>>Admin</option>
          </select>
        </div>
        <div class="field-group">
          <label class="field-label">Notes</label>
          <textarea class="field-input" name="notes" rows="2" placeholder="Optional context for the reviewer"></textarea>
        </div>
        <div class="field-group">
          <label class="field-label">Items <span style="color:var(--red)">*</span></label>
          <div id="item-rows"></div>
          <button type="button" class="act-btn" onclick="addItemRow()" style="margin-top:4px"><?= icon('plus', 13) ?> Add Item</button>
        </div>
        <div style="text-align:right;font-weight:800;font-size:15px;color:var(--espresso);margin-top:10px">
          Estimated Total: <span id="running-total">₱0.00</span>
        </div>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn-cancel" onclick="closeCreate()">Cancel</button>
        <button type="submit" class="btn-save"><?= icon('check', 14) ?> Submit for Review</button>
      </div>
    </form>
  </div>
</div>

<!-- ── Leave Request Modal ── -->
<div class="modal-overlay" id="leave-modal">
  <div class="modal">
    <div class="modal-header">
      <h3>File Leave Request</h3>
      <button class="modal-close" onclick="closeLeaveModal()"><?= icon('x', 14) ?></button>
    </div>
    <div class="modal-body">
      <div class="field-group">
        <label class="field-label">Leave Type</label>
        <select class="field-input" id="lv-type">
          <?php foreach ($leave_types as $t): ?><option value="<?= $t ?>"><?= $t ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="field-row">
        <div class="field-group">
          <label class="field-label">Start Date</label>
          <input class="field-input" type="date" id="lv-start"/>
        </div>
        <div class="field-group">
          <label class="field-label">End Date</label>
          <input class="field-input" type="date" id="lv-end"/>
        </div>
      </div>
      <div class="field-group">
        <label class="field-label">Reason</label>
        <textarea class="field-input" id="lv-reason" rows="3" placeholder="Optional"></textarea>
      </div>
      <p class="camera-error" id="leave-error" style="display:none"></p>
    </div>
    <div class="modal-actions">
      <button type="button" class="btn-mcancel" onclick="closeLeaveModal()">Cancel</button>
      <button type="button" class="btn-msave" id="leave-submit-btn" onclick="submitLeave()"><?= icon('check', 14) ?> Submit Request</button>
    </div>
  </div>
</div>

<div class="toast" id="toast" style="display:none"></div>

<script>
window.EMPLOYEE_NAME = <?= json_encode(trim($fname . ' ' . ($user['lastname'] ?? ''))) ?>;
window.HAS_EMPLOYEE   = <?= json_encode((bool)$my_employee) ?>;
window.INVENTORY_ITEMS = [];

// Fetch inventory items on page load
fetch('../api/get_ingredients.php')
  .then(r => {
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.json();
  })
  .then(items => {
    window.INVENTORY_ITEMS = items || [];
  })
  .catch(e => {
    console.error('Failed to load inventory:', e);
    window.INVENTORY_ITEMS = [];
  });

// ── Requisition Modal Functions ────────────────
function addItemRow(vals = {}) {
  const wrap = document.getElementById('item-rows');
  const row = document.createElement('div');
  row.className = 'item-row';
  
  // Build inventory dropdown HTML
  const itemOptions = window.INVENTORY_ITEMS
    .map(i => `<option value="${i.id}" data-unit="${esc(i.unit)}">${esc(i.name)}${i.brand ? ' (' + esc(i.brand) + ')' : ''}</option>`)
    .join('');
  
  const selectedId = vals.inventory_id ?? '';
  
  row.innerHTML = `
    <select class="field-input item-select" onchange="updateItemFromInventory(this)">
      <option value=""> Select Item </option>
      ${itemOptions}
    </select>
    <input type="number" class="field-input qty" placeholder="Qty" min="0.1" step="0.1" value="${esc(vals.qty ?? '')}" oninput="updateTotal()">
    <input type="text" class="field-input unit" placeholder="Unit" value="${esc(vals.unit ?? '')}" readonly style="background:#f5f5f5;cursor:not-allowed">
    <input type="number" class="field-input price" placeholder="Est. ₱/unit" min="0" step="0.01" value="${esc(vals.price ?? '')}" oninput="updateTotal()">
    <button type="button" class="rm-item" onclick="this.closest('.item-row').remove(); updateTotal();" style="display:flex;align-items:center;justify-content:center"><?= icon('x', 14) ?></button>
  `;
  wrap.appendChild(row);
  
  if (selectedId) {
    const select = row.querySelector('.item-select');
    select.value = selectedId;
  }
  
  updateTotal();
}

function updateItemFromInventory(selectEl) {
  const selectedId = selectEl.value;
  const row = selectEl.closest('.item-row');
  
  if (selectedId) {
    const item = window.INVENTORY_ITEMS.find(i => i.id == selectedId);
    if (item) {
      row.querySelector('.unit').value = item.unit || 'pcs';
    }
  } else {
    row.querySelector('.unit').value = '';
  }
  updateTotal();
}

function updateTotal() {
  let total = 0;
  document.querySelectorAll('#item-rows .item-row').forEach(row => {
    const qty   = parseFloat(row.querySelector('.qty').value) || 0;
    const price = parseFloat(row.querySelector('.price').value) || 0;
    total += qty * price;
  });
  document.getElementById('running-total').textContent = '₱' + total.toFixed(2);
}

function esc(str) {
  return String(str ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function openCreate() {
  document.getElementById('f-title').value = '';
  document.getElementById('item-rows').innerHTML = '';
  addItemRow();
  document.getElementById('create-modal').classList.add('open');
}

function closeCreate() { 
  document.getElementById('create-modal').classList.remove('open'); 
}

function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = `toast toast-${type}`;
  toast.style.display = 'block';
  toast.style.opacity = '1';
  setTimeout(() => {
    toast.style.opacity = '0';
  }, 3500);
}

document.getElementById('create-form').addEventListener('submit', function(e) {
  e.preventDefault();
  
  const errBox = document.getElementById('create-form-error');
  if (errBox) { errBox.style.display = 'none'; errBox.textContent = ''; }

  const titleInput = document.getElementById('f-title');
  if (!titleInput.value.trim()) {
    if (errBox) {
      errBox.textContent = 'Requisition title is required.';
      errBox.style.display = 'block';
    }
    titleInput.focus();
    return;
  }

  const items = [];
  let invalidQty = false;

  document.querySelectorAll('#item-rows .item-row').forEach(row => {
    const selectEl = row.querySelector('.item-select');
    const inventoryId = selectEl.value;
    const inventoryItem = window.INVENTORY_ITEMS.find(i => i.id == inventoryId);
    const name = inventoryItem ? inventoryItem.name : '';
    const qtyInput = row.querySelector('.qty');
    const qty   = parseFloat(qtyInput.value) || 0;
    const unit  = row.querySelector('.unit').value.trim();
    const price = parseFloat(row.querySelector('.price').value) || 0;
    if (name) {
      if (qty <= 0) invalidQty = true;
      items.push({ name, inventory_id: inventoryId, qty, unit, price });
    }
  });
  
  if (!items.length) {
    if (errBox) {
      errBox.textContent = 'Please add at least one item to the requisition.';
      errBox.style.display = 'block';
    }
    return;
  }

  if (invalidQty) {
    if (errBox) {
      errBox.textContent = 'Each item must have a quantity greater than 0.';
      errBox.style.display = 'block';
    }
    return;
  }
  
  // Prepare form data
  const formData = new FormData();
  formData.append('action', 'create');
  formData.append('title', document.getElementById('f-title').value);
  formData.append('department', document.querySelector('select[name="department"]').value);
  formData.append('notes', document.querySelector('textarea[name="notes"]').value);
  formData.append('items', JSON.stringify(items));
  
  const submitBtn = this.querySelector('button[type="submit"]');
  if (window.KofeeValidator && submitBtn) {
    KofeeValidator.setLoading(submitBtn, 'Submitting…');
  }

  // Submit via AJAX
  fetch('../php/requisitions.php', {
    method: 'POST',
    body: formData
  })
  .then(r => r.text())
  .then(html => {
    if (window.KofeeValidator && submitBtn) {
      KofeeValidator.resetLoading(submitBtn);
    }
    // Check if response contains success indicator
    if (html.includes('toast-success') || html.includes('Requisition submitted')) {
      showToast('Requisition submitted for review!', 'success');
      closeCreate();
      // Reset form
      document.getElementById('create-form').reset();
      document.getElementById('f-title').value = '';
      document.getElementById('item-rows').innerHTML = '';
      document.getElementById('running-total').textContent = '₱0.00';
    } else {
      if (errBox) {
        errBox.textContent = 'Failed to submit requisition. Please check your inputs.';
        errBox.style.display = 'block';
      }
      showToast('Failed to submit requisition', 'error');
    }
  })
  .catch(e => {
    if (window.KofeeValidator && submitBtn) {
      KofeeValidator.resetLoading(submitBtn);
    }
    console.error('Error:', e);
    if (errBox) {
      errBox.textContent = 'Network error while submitting requisition.';
      errBox.style.display = 'block';
    }
    showToast('Error submitting requisition', 'error');
  });
});

document.querySelectorAll('.modal-overlay').forEach(el => {
  el.addEventListener('click', e => { if (e.target === el) { closeCreate(); } });
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeCreate(); } });
</script>
<script src="../js/validator.js"></script>
<script src="../js/employee_dashboard.js?v=<?= filemtime(__DIR__.'/../js/employee_dashboard.js') ?>"></script>

</body>
</html>