<?php
require_once '../includes/auth.php';
require_once '../includes/permissions.php';
require_once '../includes/procurement_helpers.php';
require_once '../includes/icons.php';
require_login();
require_permission('procurement.view');

$pdo   = get_db();
$user  = current_user();
$toast = '';
$toast_type = 'success';

// ── POST actions ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        require_permission('procurement.invoice.create');

        $po_id     = (int)($_POST['po_id'] ?? 0);
        $inv_num   = trim($_POST['invoice_number'] ?? '');
        $inv_date  = $_POST['invoice_date'] ?: null;
        $due_date  = $_POST['due_date'] ?: null;
        $tax       = (float)($_POST['tax_amount'] ?? 0);
        $lines     = $_POST['lines'] ?? []; // [requisition_item_id => ['qty'=>.., 'unit_price'=>..]]

        $po = $pdo->prepare('SELECT * FROM purchase_orders WHERE id = :id'); $po->execute([':id' => $po_id]); $po = $po->fetch();

        if (!$po) {
            $toast = 'Purchase Order not found.'; $toast_type = 'error';
        } elseif (!$inv_num) {
            $toast = 'Invoice number is required.'; $toast_type = 'error';
        } elseif (empty($lines)) {
            $toast = 'Add at least one line item.'; $toast_type = 'error';
        } else {
            try {
                $pdo->beginTransaction();

                $subtotal = 0.0;
                $item_stmt = $pdo->prepare('SELECT * FROM requisition_items WHERE id = :id');
                $line_data = [];

                foreach ($lines as $req_item_id => $data) {
                    $qty   = (float)($data['qty'] ?? 0);
                    $price = (float)($data['unit_price'] ?? 0);
                    if ($qty <= 0) continue;

                    $item_stmt->execute([':id' => (int)$req_item_id]);
                    $ri = $item_stmt->fetch();
                    if (!$ri) continue;

                    $line_total = round($qty * $price, 2);
                    $subtotal  += $line_total;
                    $line_data[] = [
                        'requisition_item_id' => (int)$req_item_id,
                        'item_name' => $ri['item_name'],
                        'qty' => $qty, 'unit_price' => $price, 'line_total' => $line_total,
                    ];
                }

                if (empty($line_data)) {
                    throw new Exception('Enter a quantity for at least one line item.');
                }

                $total = round($subtotal + $tax, 2);

                $attachment_path = null;
                if (!empty($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                    $upload_dir = __DIR__ . '/../uploads/invoices';
                    if (!is_dir($upload_dir)) {
                        @mkdir($upload_dir, 0755, true);
                    }
                    require_once __DIR__ . '/../includes/security.php';
                    $mime = detect_upload_mime($_FILES['attachment']['tmp_name']);
                    $mime_map = [
                        'application/pdf' => 'pdf',
                        'image/jpeg'      => 'jpg',
                        'image/png'       => 'png',
                    ];
                    if (isset($mime_map[$mime])) {
                        $ext = $mime_map[$mime];
                        $fname = 'inv_' . time() . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
                        if (move_uploaded_file($_FILES['attachment']['tmp_name'], $upload_dir . '/' . $fname)) {
                            $attachment_path = 'uploads/invoices/' . $fname;
                        }
                    }
                }

                $inv_stmt = $pdo->prepare(
                    'INSERT INTO invoices (po_id, supplier_id, invoice_number, invoice_date, due_date, subtotal, tax_amount, total_amount, attachment_path, version, uploaded_by)
                     VALUES (:po, :sup, :num, :idate, :ddate, :sub, :tax, :tot, :att, 1, :u)'
                );
                $inv_stmt->execute([
                    ':po' => $po_id, ':sup' => $po['supplier_id'], ':num' => $inv_num, ':idate' => $inv_date, ':ddate' => $due_date,
                    ':sub' => $subtotal, ':tax' => $tax, ':tot' => $total, ':att' => $attachment_path, ':u' => $user['id'],
                ]);
                $invoice_id = (int)$pdo->lastInsertId();

                $li_stmt = $pdo->prepare(
                    'INSERT INTO invoice_items (invoice_id, requisition_item_id, item_name, qty, unit_price, line_total)
                     VALUES (:inv, :ri, :n, :q, :p, :lt)'
                );
                foreach ($line_data as $l) {
                    $li_stmt->execute([
                        ':inv' => $invoice_id, ':ri' => $l['requisition_item_id'], ':n' => $l['item_name'],
                        ':q' => $l['qty'], ':p' => $l['unit_price'], ':lt' => $l['line_total'],
                    ]);
                }

                $pdo->commit();
                audit_log('invoice', $invoice_id, 'created', "PO #$po_id — {$inv_num} — " . php_currency($total));

                notify_role_by_permission(
                    'procurement.invoice.match', 'invoice_created',
                    "Invoice {$inv_num} logged for PO #$po_id",
                    'Ready for 3-way match against PO and Goods Receipt.',
                    'three_way_match.php?invoice_id=' . $invoice_id, $user['id']
                );

                $toast = 'Invoice logged. Ready for 3-way matching.';
                header('Location: invoices.php?id=' . $invoice_id . '&toast=' . urlencode($toast) . '&type=success');
                exit;
            } catch (Exception $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $toast = $e->getMessage(); $toast_type = 'error';
            }
        }
    }

    if ($action === 'request_correction') {
        require_permission('procurement.invoice.match');
        $id = (int)($_POST['id'] ?? 0);
        $notes = trim($_POST['correction_notes'] ?? '');
        if (!$notes) {
            $toast = 'Please provide details on what needs correction.'; $toast_type = 'error';
        } else {
            $inv_stmt = $pdo->prepare('SELECT * FROM invoices WHERE id = :id');
            $inv_stmt->execute([':id' => $id]);
            $inv = $inv_stmt->fetch();
            if ($inv) {
                $pdo->prepare("UPDATE invoices SET status = 'needs_correction', correction_notes = :cn WHERE id = :id")
                    ->execute([':cn' => $notes, ':id' => $id]);
                audit_log('invoice', $id, 'correction_requested', $notes);

                // Notify supplier
                $sup_stmt = $pdo->prepare('SELECT user_id FROM suppliers WHERE id = :sid');
                $sup_stmt->execute([':sid' => $inv['supplier_id']]);
                $sup_uid = (int)$sup_stmt->fetchColumn();
                if ($sup_uid > 0) {
                    notify_user(
                        $sup_uid,
                        'invoice_correction_needed',
                        "Invoice {$inv['invoice_number']} Needs Correction",
                        "Finance requested a correction: \"{$notes}\". Please update and resubmit.",
                        "supplier_portal.php?tab=invoices&invoice_id={$id}"
                    );
                }
                $toast = 'Correction request sent to supplier. Invoice marked needs correction.';
            }
        }
        header('Location: invoices.php?id=' . $id . '&toast=' . urlencode($toast) . '&type=' . $toast_type);
        exit;
    }

    if ($action === 'cancel') {
        require_permission('procurement.invoice.create');
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare("UPDATE invoices SET status='cancelled' WHERE id=:id AND status IN ('pending','disputed','submitted','needs_correction')")->execute([':id' => $id]);
        audit_log('invoice', $id, 'cancelled');
        $toast = 'Invoice cancelled.';
        header('Location: invoices.php?id=' . $id . '&toast=' . urlencode($toast) . '&type=success');
        exit;
    }

    $q = ($toast ? '&toast=' . urlencode($toast) . '&type=' . $toast_type : '');
    header('Location: invoices.php' . $q);
    exit;
}

if (isset($_GET['toast'])) {
    $toast      = htmlspecialchars($_GET['toast']);
    $toast_type = $_GET['type'] ?? 'success';
}

// ── Detail view ──────────────────────────────
$view_id = (int)($_GET['id'] ?? 0);
$invoice = null; $invoice_items = [];
if ($view_id) {
    $stmt = $pdo->prepare('
        SELECT i.*, s.name AS supplier_name, po.total_amount AS po_total, pr.title AS req_title, pr.department
        FROM invoices i
        JOIN suppliers s ON s.id = i.supplier_id
        JOIN purchase_orders po ON po.id = i.po_id
        JOIN purchase_requisitions pr ON pr.id = po.requisition_id
        WHERE i.id = :id
    ');
    $stmt->execute([':id' => $view_id]);
    $invoice = $stmt->fetch();

    if ($invoice) {
        $li = $pdo->prepare('SELECT * FROM invoice_items WHERE invoice_id = :id');
        $li->execute([':id' => $view_id]);
        $invoice_items = $li->fetchAll();

        $pay_stmt = $pdo->prepare('SELECT * FROM payments WHERE invoice_id = :id ORDER BY id DESC');
        $pay_stmt->execute([':id' => $view_id]);
        $invoice_payments = $pay_stmt->fetchAll();
    }
}

// ── "New invoice" form context: POs eligible for invoicing ──────────
$new_po_id = (int)($_GET['new_for_po'] ?? 0);
$new_po = null; $new_po_items = [];
if ($new_po_id) {
    $stmt = $pdo->prepare('
        SELECT po.*, s.name AS supplier_name, pr.title AS req_title, pr.id AS requisition_id
        FROM purchase_orders po JOIN suppliers s ON s.id = po.supplier_id JOIN purchase_requisitions pr ON pr.id = po.requisition_id
        WHERE po.id = :id
    ');
    $stmt->execute([':id' => $new_po_id]);
    $new_po = $stmt->fetch();
    if ($new_po) {
        $ri = $pdo->prepare('SELECT * FROM requisition_items WHERE requisition_id = :rid');
        $ri->execute([':rid' => $new_po['requisition_id']]);
        $new_po_items = $ri->fetchAll();
    }
}

$eligible_stmt = $pdo->query("
    SELECT po.id, po.total_amount, s.name AS supplier_name, pr.title AS req_title
    FROM purchase_orders po
    JOIN suppliers s ON s.id = po.supplier_id
    JOIN purchase_requisitions pr ON pr.id = po.requisition_id
    WHERE po.status IN ('delivered','closed')
      AND po.id NOT IN (SELECT po_id FROM invoices WHERE status != 'cancelled')
    ORDER BY po.delivered_at DESC
");
$eligible_pos = $eligible_stmt->fetchAll();

$filter = $_GET['status'] ?? 'all';
$where  = '1=1'; $params = [];
if (in_array($filter, ['submitted','pending','matched','needs_correction','disputed','approved','partially_paid','paid','cancelled'], true)) {
    $where .= ' AND i.status = :st'; $params[':st'] = $filter;
}
$list_stmt = $pdo->prepare("
    SELECT i.*, s.name AS supplier_name, po.id AS po_id
    FROM invoices i JOIN suppliers s ON s.id = i.supplier_id JOIN purchase_orders po ON po.id = i.po_id
    WHERE $where ORDER BY i.created_at DESC
");
$list_stmt->execute($params);
$invoices = $list_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Invoices — Kofee POS</title>
  <link rel="stylesheet" href="../css/style.css"/>
  <link rel="stylesheet" href="../css/sidebar.css"/>
  <style>
    .inv-line-row { display:grid; grid-template-columns: 1.6fr .8fr .8fr .9fr; gap:10px; align-items:center; padding:9px 0; border-bottom:1px dashed var(--border); font-size:13px; }
    .inv-line-row:last-child { border-bottom:none; }
    .inv-total-strip { display:flex; justify-content:flex-end; gap:24px; padding-top:12px; margin-top:6px; border-top:1.5px solid var(--border); font-size:13px; }
  </style>
</head>
<body>
<?php include("../includes/sidebar.php"); ?>

<div id="page-invoices" class="page active">
  <div class="page-header">
    <div>
      <h1>Invoices</h1>
      <p>Log supplier invoices and prepare them for 3-way matching</p>
    </div>
  </div>

  <div class="page-body">

    <?php if ($toast): ?>
    <div class="toast toast-<?= $toast_type ?>" style="position:static;display:inline-flex;margin-bottom:4px"><?= $toast ?></div>
    <?php endif; ?>

    <?php if ($new_po): ?>
      <!-- ── New invoice form ── -->
      <div class="table-card" style="padding:20px 22px">
        <h2>New Invoice — <?= htmlspecialchars($new_po['req_title']) ?></h2>
        <p class="muted-cell" style="margin-bottom:16px">PO #<?= str_pad($new_po['id'],5,'0',STR_PAD_LEFT) ?> · <?= htmlspecialchars($new_po['supplier_name']) ?> · PO Total: <?= php_currency($new_po['total_amount']) ?></p>

        <form method="POST" id="invoice-form" enctype="multipart/form-data">
          <input type="hidden" name="action" value="create"/>
          <input type="hidden" name="po_id" value="<?= $new_po['id'] ?>"/>

          <div id="invoice-error" style="display:none;margin-bottom:14px;padding:10px 14px;border-radius:var(--radius-sm);background:var(--red-lt);color:var(--red);font-size:12.5px;font-weight:600"></div>

          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:14px">
            <div>
              <input class="field-input" type="text" name="invoice_number" id="f-inv-num" placeholder="Invoice Number *" required/>
            </div>
            <div>
              <input class="field-input" type="date" name="invoice_date" id="f-inv-date" placeholder="Invoice Date"/>
            </div>
            <div>
              <input class="field-input" type="date" name="due_date" id="f-due-date" placeholder="Due Date"/>
            </div>
          </div>

          <div style="margin-bottom:16px">
            <label style="font-size:12px;font-weight:600;color:var(--text-muted);display:block;margin-bottom:4px">Invoice Document / Receipt (PDF, JPG, PNG)</label>
            <input class="field-input" type="file" name="attachment" accept=".pdf,.jpg,.jpeg,.png"/>
          </div>

          <div class="inv-line-row" style="font-size:11px;color:var(--text-muted);font-weight:700;text-transform:uppercase;border-bottom:1.5px solid var(--border)">
            <div>Item</div><div>Qty</div><div>Unit Price</div><div>Line Total</div>
          </div>
          <?php foreach ($new_po_items as $ri): ?>
            <div class="inv-line-row">
              <div><?= htmlspecialchars($ri['item_name']) ?> <span class="muted-cell">(<?= htmlspecialchars($ri['unit']) ?>)</span></div>
              <div><input class="field-input" type="number" step="0.01" min="0" style="padding:6px 8px" name="lines[<?= $ri['id'] ?>][qty]" value="<?= $ri['quantity'] ?>"/></div>
              <div><input class="field-input" type="number" step="0.01" min="0" style="padding:6px 8px" name="lines[<?= $ri['id'] ?>][unit_price]" value="<?= $ri['est_unit_price'] ?>"/></div>
              <div class="muted-cell">computed on save</div>
            </div>
          <?php endforeach; ?>

          <div style="display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center;margin-top:14px">
            <label style="font-size:12.5px">Tax / other charges (₱)
              <input class="field-input" type="number" step="0.01" min="0" name="tax_amount" value="0" style="margin-top:4px"/>
            </label>
          </div>

          <div style="margin-top:16px;text-align:right;display:flex;gap:10px;justify-content:flex-end">
            <a href="invoices.php" class="btn-cancel">Cancel</a>
            <button type="submit" class="btn-save" id="invoice-submit-btn"><?= icon('invoice', 14) ?> Log Invoice</button>
          </div>
        </form>
      </div>

    <?php elseif ($invoice): ?>
      <!-- ── Invoice detail ── -->
      <div class="table-card" style="padding:20px 22px;margin-bottom:18px">
        <div style="display:flex;justify-content:space-between;align-items:flex-start">
          <div>
            <div style="display:flex;align-items:center;gap:8px">
              <h2 style="margin:0"><?= htmlspecialchars($invoice['invoice_number']) ?></h2>
              <?php if (!empty($invoice['version'])): ?>
                <span style="background:#e8f4fd;color:#0b72b9;font-weight:700;font-size:11px;padding:2px 8px;border-radius:6px">v<?= (int)$invoice['version'] ?></span>
              <?php endif; ?>
            </div>
            <p class="muted-cell" style="margin-top:4px">PO #<?= str_pad($invoice['po_id'],5,'0',STR_PAD_LEFT) ?> · <?= htmlspecialchars($invoice['supplier_name']) ?> · <?= htmlspecialchars($invoice['req_title']) ?></p>
          </div>
          <span class="status-badge status-<?= in_array($invoice['status'],['approved','matched','paid'])?'approved':(in_array($invoice['status'],['disputed','needs_correction','cancelled','rejected'])?'rejected':'pending') ?>"><?= status_badge($invoice['status']) ?></span>
        </div>

        <?php if (!empty($invoice['attachment_path'])): ?>
          <div style="margin-top:12px">
            <a href="../<?= htmlspecialchars($invoice['attachment_path']) ?>" target="_blank" class="btn-cancel" style="display:inline-flex;align-items:center;gap:6px;font-size:12px;text-decoration:none">
              <?= icon('file-text', 13) ?> View Attached Invoice Document
            </a>
          </div>
        <?php endif; ?>

        <div class="inv-line-row" style="font-size:11px;color:var(--text-muted);font-weight:700;text-transform:uppercase;border-bottom:1.5px solid var(--border);margin-top:16px">
          <div>Item</div><div>Qty</div><div>Unit Price</div><div>Line Total</div>
        </div>
        <?php foreach ($invoice_items as $li): ?>
          <div class="inv-line-row">
            <div><?= htmlspecialchars($li['item_name']) ?></div>
            <div><?= number_format($li['qty'],2) ?></div>
            <div><?= php_currency($li['unit_price']) ?></div>
            <div style="font-weight:700"><?= php_currency($li['line_total']) ?></div>
          </div>
        <?php endforeach; ?>

        <div class="inv-total-strip">
          <div>Subtotal: <strong><?= php_currency($invoice['subtotal']) ?></strong></div>
          <div>Tax: <strong><?= php_currency($invoice['tax_amount']) ?></strong></div>
          <div>Total: <strong style="color:var(--espresso)"><?= php_currency($invoice['total_amount']) ?></strong></div>
        </div>

        <?php if (!empty($invoice_payments)): ?>
          <div style="margin-top:16px;background:var(--cream,#FAF7F2);border:1px solid var(--border,#e8ded2);border-radius:10px;padding:14px 16px">
            <h4 style="margin:0 0 10px;font-size:13px;display:flex;align-items:center;gap:6px">
              <?= icon('dollar', 14) ?> Recorded Payments (<?= count($invoice_payments) ?>)
            </h4>
            <div style="overflow-x:auto">
              <table style="width:100%;font-size:12px;border-collapse:collapse">
                <thead>
                  <tr style="text-align:left;border-bottom:1px solid var(--border,#e8ded2);color:var(--text-muted)">
                    <th style="padding:6px 8px">Date</th>
                    <th style="padding:6px 8px">Method &amp; Account</th>
                    <th style="padding:6px 8px">Reference</th>
                    <th style="padding:6px 8px">Amount</th>
                    <th style="padding:6px 8px">Status</th>
                    <th style="padding:6px 8px">Supplier Confirmation</th>
                    <th style="padding:6px 8px">Proof</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($invoice_payments as $ip): ?>
                    <tr style="border-bottom:1px dashed var(--border,#e8ded2)">
                      <td style="padding:6px 8px"><?= date('M d, Y', strtotime($ip['payment_date'] ?: $ip['completed_at'] ?: $ip['scheduled_at'])) ?></td>
                      <td style="padding:6px 8px">
                        <strong><?= ucwords(str_replace('_',' ',$ip['payment_method'])) ?></strong>
                        <?php if ($ip['paying_account']): ?>
                          <div style="font-size:10.5px;color:var(--text-muted)"><?= htmlspecialchars($ip['paying_account']) ?></div>
                        <?php endif; ?>
                      </td>
                      <td style="padding:6px 8px"><?= htmlspecialchars($ip['reference_no'] ?: '—') ?></td>
                      <td style="padding:6px 8px;font-weight:700"><?= php_currency($ip['amount']) ?></td>
                      <td style="padding:6px 8px"><span class="status-badge status-<?= $ip['status']==='completed'?'approved':($ip['status']==='failed'?'rejected':'pending') ?>"><?= status_badge($ip['status']) ?></span></td>
                      <td style="padding:6px 8px">
                        <?php if ($ip['status'] === 'completed'): ?>
                          <?php if ($ip['supplier_confirmation_status'] === 'confirmed'): ?>
                            <span style="color:#16a34a;font-weight:700">● Confirmed</span>
                          <?php elseif ($ip['supplier_confirmation_status'] === 'disputed'): ?>
                            <span style="color:#dc2626;font-weight:700">● Disputed</span>
                          <?php else: ?>
                            <span style="color:#d97706;font-weight:700">● Awaiting</span>
                          <?php endif; ?>
                        <?php else: ?>
                          &mdash;
                        <?php endif; ?>
                      </td>
                      <td style="padding:6px 8px">
                        <?php if (!empty($ip['receipt_attachment_path'])): ?>
                          <a href="../<?= htmlspecialchars($ip['receipt_attachment_path']) ?>" target="_blank" style="color:var(--caramel);font-weight:600">View Proof</a>
                        <?php else: ?>
                          &mdash;
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        <?php endif; ?>

        <?php if (!empty($invoice['correction_notes'])): ?>
          <div style="margin-top:14px;padding:12px 14px;border-radius:10px;background:#FFF3CD;border:1px solid #FFEBAA;color:#856404;font-size:13px">
            <strong><?= icon('alert-triangle', 14) ?> Correction Requested:</strong>
            <p style="margin:4px 0 0 0"><?= nl2br(htmlspecialchars($invoice['correction_notes'])) ?></p>
          </div>
        <?php endif; ?>

        <?php if ($invoice['match_notes']): ?>
          <p style="margin-top:12px;font-size:12.5px;color:var(--text-muted);font-style:italic;padding:10px;background:#FBF6EF;border-radius:10px">Match notes: <?= htmlspecialchars($invoice['match_notes']) ?></p>
        <?php endif; ?>

        <div style="margin-top:16px;display:flex;gap:10px;justify-content:flex-end;flex-wrap:wrap">
          <?php if (in_array($invoice['status'], ['pending','disputed','submitted','needs_correction'], true) && has_permission('procurement.invoice.create')): ?>
            <form method="POST" onsubmit="return confirm('Cancel this invoice?')">
              <input type="hidden" name="action" value="cancel"/><input type="hidden" name="id" value="<?= $invoice['id'] ?>"/>
              <button type="submit" class="btn-cancel"><?= icon('x', 13) ?> Cancel Invoice</button>
            </form>
          <?php endif; ?>
          <?php if (in_array($invoice['status'], ['pending','disputed','submitted','matched'], true) && has_permission('procurement.invoice.match')): ?>
            <button type="button" class="btn-cancel" onclick="document.getElementById('correction-form-wrap').style.display='block';this.style.display='none'" style="color:var(--red);border-color:var(--red)">
              <?= icon('message', 13) ?> Request Correction
            </button>
            <a href="three_way_match.php?invoice_id=<?= $invoice['id'] ?>" class="btn-save"><?= icon('link', 13) ?> Run 3-Way Match</a>
          <?php endif; ?>
          <?php if (in_array($invoice['status'], ['approved', 'partially_paid'], true) && has_permission('procurement.payment.process')): ?>
            <a href="payments.php?new_for_invoice=<?= $invoice['id'] ?>" class="btn-save"><?= icon('dollar', 13) ?> Record Payment</a>
          <?php endif; ?>
        </div>

        <?php if (has_permission('procurement.invoice.match')): ?>
        <div id="correction-form-wrap" style="display:none;margin-top:16px;padding:16px;background:#FEF6E9;border:1.5px solid #F5D8A0;border-radius:10px">
          <h4 style="margin:0 0 8px 0;font-size:13.5px;color:var(--espresso)">Request Correction from Supplier</h4>
          <p style="margin:0 0 10px 0;font-size:12px;color:var(--text-muted)">State the exact discrepancy (e.g. quantity difference, incorrect price, missing attachment) so the supplier can resubmit.</p>
          <form method="POST">
            <input type="hidden" name="action" value="request_correction"/>
            <input type="hidden" name="id" value="<?= $invoice['id'] ?>"/>
            <textarea class="field-input" name="correction_notes" rows="3" placeholder="Describe the correction required..." required style="margin-bottom:10px"><?= htmlspecialchars($invoice['correction_notes'] ?? '') ?></textarea>
            <div style="display:flex;gap:8px;justify-content:flex-end">
              <button type="button" class="btn-cancel" onclick="document.getElementById('correction-form-wrap').style.display='none'">Cancel</button>
              <button type="submit" class="btn-save" style="background:var(--red)"><?= icon('send', 13) ?> Send Request to Supplier</button>
            </div>
          </form>
        </div>
        <?php endif; ?>
      </div>
      <p><a href="invoices.php" style="font-size:12.5px;color:var(--caramel);font-weight:600">← Back to Invoices</a></p>

    <?php else: ?>
      <!-- ── List view ── -->
      <?php if (has_permission('procurement.invoice.create')): ?>
<div class="table-card" style="padding:0;margin-bottom:18px;overflow:hidden">
  <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1.5px solid var(--border)">
    <h3 style="font-size:13.5px;font-weight:700;color:var(--espresso);display:flex;align-items:center;gap:6px;margin:0">
      <?= icon('invoice', 16) ?> Log a New Invoice
    </h3>
    <?php if (!empty($eligible_pos)): ?>
      <span class="count-badge" style="background:var(--blue-lt);color:var(--blue)"><?= count($eligible_pos) ?></span>
    <?php endif; ?>
  </div>

  <?php if (empty($eligible_pos)): ?>
    <div style="padding:30px 18px;text-align:center;color:var(--text-muted);font-size:13px">
      No delivered Purchase Orders awaiting invoicing right now.
    </div>
  <?php else: ?>
    <div>
      <?php foreach ($eligible_pos as $ep): ?>
        <div class="kf-invoice-row" onclick="window.location.href='invoices.php?new_for_po=<?= $ep['id'] ?>'">
          <div class="kf-invoice-icon" style="background:var(--blue-lt)"><?= icon('package', 18) ?></div>
          <div class="kf-invoice-info">
            <div class="kf-invoice-num">
              PO #<?= str_pad($ep['id'],5,'0',STR_PAD_LEFT) ?>
            </div>
            <div class="kf-invoice-supplier">
              <?= htmlspecialchars($ep['supplier_name']) ?>
            </div>
          </div>
          <div class="kf-invoice-amount">
            <?= php_currency($ep['total_amount']) ?>
          </div>
          <button class="act-btn act-activate" onclick="event.stopPropagation();window.location.href='invoices.php?new_for_po=<?= $ep['id'] ?>'">
            Log Invoice
          </button>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<style>
.kf-invoice-row {
  display: flex; align-items: center; gap: 12px;
  padding: 13px 18px;
  border-bottom: 1px solid #F2E6D6;
  cursor: pointer;
  transition: background .12s ease;
}
.kf-invoice-row:last-child { border-bottom: none; }
.kf-invoice-row:hover { background: #FEFAF4; }

.kf-invoice-icon {
  width: 36px; height: 36px; border-radius: 10px; flex-shrink: 0;
  display: flex; align-items: center; justify-content: center;
  font-size: 16px;
}
.kf-invoice-info { flex: 1; min-width: 0; }
.kf-invoice-num {
  font-size: 13px; font-weight: 700; color: var(--espresso);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.kf-invoice-supplier {
  font-size: 11.5px; color: var(--text-muted); margin-top: 1px;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.kf-invoice-amount {
  font-size: 14px; font-weight: 800; color: var(--espresso);
  flex-shrink: 0; white-space: nowrap;
}

@media (max-width: 600px) {
  .kf-invoice-row { flex-wrap: wrap; }
  .kf-invoice-amount { order: 3; margin-left: 48px; }
  .kf-invoice-info { order: 2; }
}
</style>
      <?php endif; ?>

      <div class="filter-bar" style="padding:0">
        <a href="invoices.php" class="filter-pill <?= $filter==='all'?'active':'' ?>">All</a>
        <a href="invoices.php?status=submitted" class="filter-pill <?= $filter==='submitted'?'active':'' ?>">Submitted</a>
        <a href="invoices.php?status=pending" class="filter-pill <?= $filter==='pending'?'active':'' ?>">Pending</a>
        <a href="invoices.php?status=matched" class="filter-pill <?= $filter==='matched'?'active':'' ?>">Matched</a>
        <a href="invoices.php?status=needs_correction" class="filter-pill <?= $filter==='needs_correction'?'active':'' ?>">Needs Correction</a>
        <a href="invoices.php?status=disputed" class="filter-pill <?= $filter==='disputed'?'active':'' ?>">Disputed</a>
        <a href="invoices.php?status=approved" class="filter-pill <?= $filter==='approved'?'active':'' ?>">Approved</a>
        <a href="invoices.php?status=partially_paid" class="filter-pill <?= $filter==='partially_paid'?'active':'' ?>">Partially Paid</a>
        <a href="invoices.php?status=paid" class="filter-pill <?= $filter==='paid'?'active':'' ?>">Paid</a>
      </div>
      <div class="table-scroll-hint">
        <span><?= icon('chevron-right', 12) ?> Swipe to view all 7 columns</span>
      </div>
      <div class="table-scroll-wrapper">
        <table>
          <thead><tr><th class="col-sticky">Invoice #</th><th>PO #</th><th>Supplier</th><th>Total</th><th>Status</th><th>Date</th><th style="text-align:center;width:95px">Action</th></tr></thead>
          <tbody>
          <?php if (empty($invoices)): ?>
            <tr class="empty-row"><td colspan="7"><?= icon('inbox', 18) ?> No invoices logged yet.</td></tr>
          <?php else: foreach ($invoices as $i): ?>
            <tr>
              <td class="col-sticky" style="font-weight:700">
                <?= htmlspecialchars($i['invoice_number']) ?>
                <?php if (!empty($i['version']) && $i['version'] > 1): ?>
                  <span style="background:#e8f4fd;color:#0b72b9;font-weight:700;font-size:10px;padding:1px 5px;border-radius:4px;margin-left:4px">v<?= (int)$i['version'] ?></span>
                <?php endif; ?>
              </td>
              <td>#<?= str_pad($i['po_id'],5,'0',STR_PAD_LEFT) ?></td>
              <td><?= htmlspecialchars($i['supplier_name']) ?></td>
              <td style="font-weight:700"><?= php_currency($i['total_amount']) ?></td>
              <td><span class="status-badge status-<?= in_array($i['status'],['approved','matched','paid'])?'approved':(in_array($i['status'],['disputed','needs_correction','cancelled','rejected'])?'rejected':'pending') ?>"><?= status_badge($i['status']) ?></span></td>
              <td class="muted-cell"><?= date('M d, Y', strtotime($i['created_at'])) ?></td>
              <td style="text-align:center"><button class="act-btn" onclick="window.location.href='invoices.php?id=<?= $i['id'] ?>'"><?= icon('eye', 13) ?> View</button></td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

  </div>
</div>

<script src="../js/validator.js"></script>
<script>
const invForm = document.getElementById('invoice-form');
if (invForm && window.KofeeValidator) {
  KofeeValidator.attach(invForm, {
    customValidate: function(form) {
      const errBox = document.getElementById('invoice-error');
      if (errBox) { errBox.style.display = 'none'; errBox.textContent = ''; }

      const invNum = form.querySelector('[name="invoice_number"]');
      if (!invNum || !invNum.value.trim()) {
        return { field: invNum, message: 'Invoice number is required.' };
      }

      const invDate = form.querySelector('[name="invoice_date"]')?.value;
      const dueDate = form.querySelector('[name="due_date"]')?.value;

      if (invDate && dueDate && new Date(dueDate).getTime() < new Date(invDate).getTime()) {
        return { field: form.querySelector('[name="due_date"]'), message: 'Due date cannot be before invoice date.' };
      }

      return true;
    },
    loadingText: 'Logging Invoice…'
  });
}
</script>
</body>
</html>