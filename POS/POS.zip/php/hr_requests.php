<?php
require_once '../includes/auth.php';
require_once '../includes/permissions.php';
require_once '../includes/icons.php';
require_login();

$pdo   = get_db();
$user  = current_user();
$role  = $user['role'] ?? 'crew';
$roles = $user['roles'] ?? [$role];
$toast = '';
$toast_type = 'success';

// Reviewer check: Admin, HR, Manager, or users with requests.manage permission
$is_reviewer = in_array('admin', $roles, true)
            || in_array('hr', $roles, true)
            || in_array('manager', $roles, true)
            || has_permission('requests.manage');

$request_types = ['Certificate of Employment','ID Replacement','Schedule Change','Payslip Copy','Document Correction','Other'];

// ── Resolve the logged-in user's own employee profile (for self-service filing) ──
$stmt = $pdo->prepare('SELECT * FROM employees WHERE user_id = :uid LIMIT 1');
$stmt->execute([':uid' => $user['id']]);
$my_employee = $stmt->fetch() ?: null;
if (!$my_employee && !$is_reviewer) {
    $my_employee = get_or_create_user_employee($pdo, (int)$user['id']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ── File a request — tied to user's OWN employee record ──
    if ($action === 'file') {
        if (!$my_employee) {
            $toast = "Your account isn't linked to an employee profile yet. Ask HR to link it first."; $toast_type = 'error';
        } else {
            $type    = trim($_POST['request_type'] ?? '');
            $type    = $type ?: 'Other';
            $details = trim($_POST['details'] ?? '');

            $pdo->prepare('INSERT INTO hr_requests (employee_id, request_type, details, status) VALUES (:e,:t,:d,"pending")')
                ->execute([':e' => $my_employee['id'], ':t' => $type, ':d' => $details]);
            $toast = 'Request filed successfully.';
        }
    }

    // ── Approve / Reject / Complete — reviewers only ──
    if ($action === 'review') {
        if (!$is_reviewer) {
            $toast = 'Only authorized HR / managers can review requests.'; $toast_type = 'error';
        } else {
            $id     = (int)($_POST['id'] ?? 0);
            $status = $_POST['status'] ?? '';
            if ($id && in_array($status, ['approved','rejected','completed'])) {
                $pdo->prepare('UPDATE hr_requests SET status=:s, reviewed_by=:u, reviewed_at=NOW() WHERE id=:id')
                    ->execute([':s'=>$status, ':u'=>$user['id'], ':id'=>$id]);
                $labels = ['approved'=>'Request approved.', 'rejected'=>'Request rejected.', 'completed'=>'Request marked completed.'];
                $toast  = $labels[$status];
            }
        }
    }

    // ── Delete — reviewers can remove any; requesters can cancel their OWN pending request ──
    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            if ($is_reviewer) {
                $pdo->prepare('DELETE FROM hr_requests WHERE id=:id')->execute([':id'=>$id]);
                $toast = 'Request deleted.';
            } elseif ($my_employee) {
                $del = $pdo->prepare("DELETE FROM hr_requests WHERE id=:id AND employee_id=:e AND status='pending'");
                $del->execute([':id'=>$id, ':e'=>$my_employee['id']]);
                $toast = $del->rowCount() ? 'Request cancelled.' : 'Only your own pending requests can be cancelled.';
                if (!$del->rowCount()) $toast_type = 'error';
            }
        }
    }

    $q = $toast ? '?toast=' . urlencode($toast) . '&type=' . $toast_type : '';
    header('Location: hr_requests.php' . $q);
    exit;
}

if (isset($_GET['toast'])) {
    $toast      = htmlspecialchars($_GET['toast']);
    $toast_type = $_GET['type'] ?? 'success';
}

$filter = $_GET['status'] ?? 'all';

$where  = '1=1';
$params = [];

if (!$is_reviewer) {
    // Requesters only ever see their own requests
    $where .= ' AND r.employee_id = :myid';
    $params[':myid'] = $my_employee['id'] ?? 0;
}

if (in_array($filter, ['pending','approved','rejected','completed'])) {
    $where .= ' AND r.status = :st';
    $params[':st'] = $filter;
}

$stmt = $pdo->prepare("
    SELECT r.*, e.firstname, e.lastname, e.employee_code
    FROM hr_requests r
    JOIN employees e ON e.id = r.employee_id
    WHERE $where
    ORDER BY FIELD(r.status,'pending','approved','completed','rejected'), r.created_at DESC
");
$stmt->execute($params);
$requests = $stmt->fetchAll();

$pending_c = 0; $approved_c = 0; $completed_c = 0;
foreach ($requests as $r) {
    if ($r['status']==='pending') $pending_c++;
    elseif ($r['status']==='approved') $approved_c++;
    elseif ($r['status']==='completed') $completed_c++;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Requests — Kofee POS</title>
<link rel="stylesheet" href="../css/style.css"/>
<link rel="stylesheet" href="../css/sidebar.css"/>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
<style>
  /* hr_requests.css was referenced but never shipped — these are the
     few bits this page needs beyond the shared style.css tokens. */
  .notice-banner {
    background: var(--amber-lt); color: var(--amber);
    border: 1.5px solid #f0dcb8; border-radius: var(--radius-sm);
    padding: 12px 16px; font-size: 13px; font-weight: 600;
  }
  .req { color: var(--red); }
</style>
</head>
<body>
<?php include("../includes/sidebar.php"); ?>

<div id="page-hrrequests" class="page active">
  <div class="page-header">
    <div>
      <h1>Requests</h1>
      <p><?= $is_reviewer ? 'Review employee document & administrative requests' : 'File and track your requests' ?></p>
    </div>
    <?php if ($my_employee): ?>
      <button class="btn btn-primary" onclick="openFile()"><?= icon('plus', 16) ?> <span>New Request</span></button>
    <?php endif; ?>
  </div>

  <div class="page-body">

    <?php if (!$is_reviewer && !$my_employee): ?>
      <div class="notice-banner">
        Your account isn't linked to an employee profile yet, so you can't file requests. Ask HR to link your account on the Employees page.
      </div>
    <?php endif; ?>

    <div class="stat-row">
      <div class="mini-stat"><div class="mini-stat-icon" style="background:#fff3e0;color:#e67e22"><?= icon('clock', 18) ?></div><div><div class="mini-stat-val"><?= $pending_c ?></div><div class="mini-stat-lbl">Pending</div></div></div>
      <div class="mini-stat"><div class="mini-stat-icon" style="background:#e8f5e9;color:#27ae60"><?= icon('check-circle', 18) ?></div><div><div class="mini-stat-val"><?= $approved_c ?></div><div class="mini-stat-lbl">Approved</div></div></div>
      <div class="mini-stat"><div class="mini-stat-icon" style="background:#e3f2fd;color:#2980b9"><?= icon('package', 18) ?></div><div><div class="mini-stat-val"><?= $completed_c ?></div><div class="mini-stat-lbl">Completed</div></div></div>
    </div>

    <div class="filter-bar">
      <a href="hr_requests.php" class="filter-pill <?= $filter==='all'?'active':'' ?>">All</a>
      <a href="hr_requests.php?status=pending" class="filter-pill <?= $filter==='pending'?'active':'' ?>">Pending</a>
      <a href="hr_requests.php?status=approved" class="filter-pill <?= $filter==='approved'?'active':'' ?>">Approved</a>
      <a href="hr_requests.php?status=completed" class="filter-pill <?= $filter==='completed'?'active':'' ?>">Completed</a>
      <a href="hr_requests.php?status=rejected" class="filter-pill <?= $filter==='rejected'?'active':'' ?>">Rejected</a>
    </div>

    <div class="table-card">
      <div class="table-scroll-hint">
        <span><?= icon('chevron-right', 12) ?> Swipe to view all columns</span>
      </div>
      <div class="table-scroll-wrapper">
        <table>
          <thead>
            <tr>
              <?php if ($is_reviewer): ?><th class="col-sticky">Employee</th><?php else: ?><th class="col-sticky">Request Type</th><?php endif; ?>
              <?php if ($is_reviewer): ?><th>Request Type</th><?php endif; ?>
              <th>Details</th><th>Filed</th><th>Status</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php if (empty($requests)): ?>
            <tr class="empty-row"><td colspan="<?= $is_reviewer ? 6 : 5 ?>"><?= icon('requests', 16) ?> No requests found.</td></tr>
          <?php else: foreach ($requests as $r): ?>
            <tr>
              <?php if ($is_reviewer): ?>
                <td class="col-sticky" style="font-weight:700"><?= htmlspecialchars($r['firstname'].' '.$r['lastname']) ?> <span style="color:var(--text-muted);font-weight:400">#<?= htmlspecialchars($r['employee_code']) ?></span></td>
                <td><?= htmlspecialchars($r['request_type']) ?></td>
              <?php else: ?>
                <td class="col-sticky" style="font-weight:700"><?= htmlspecialchars($r['request_type']) ?></td>
              <?php endif; ?>
              <td style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text-muted)"><?= htmlspecialchars($r['details'] ?: '—') ?></td>
              <td style="color:var(--text-muted);font-size:12px"><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
              <td><span class="status-badge status-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
              <td>
                <div class="act-group">
                  <?php if ($is_reviewer): ?>
                    <?php if ($r['status'] === 'pending'): ?>
                      <form method="POST" style="display:inline">
                        <input type="hidden" name="action" value="review"/>
                        <input type="hidden" name="id" value="<?= $r['id'] ?>"/>
                        <input type="hidden" name="status" value="approved"/>
                        <button type="submit" class="act-btn act-activate"><?= icon('check', 13) ?> Approve</button>
                      </form>
                      <form method="POST" style="display:inline">
                        <input type="hidden" name="action" value="review"/>
                        <input type="hidden" name="id" value="<?= $r['id'] ?>"/>
                        <input type="hidden" name="status" value="rejected"/>
                        <button type="submit" class="act-btn act-block"><?= icon('x', 13) ?> Reject</button>
                      </form>
                    <?php elseif ($r['status'] === 'approved'): ?>
                      <form method="POST" style="display:inline">
                        <input type="hidden" name="action" value="review"/>
                        <input type="hidden" name="id" value="<?= $r['id'] ?>"/>
                        <input type="hidden" name="status" value="completed"/>
                        <button type="submit" class="act-btn act-hold"><?= icon('package', 13) ?> Mark Completed</button>
                      </form>
                    <?php endif; ?>
                  <?php else: ?>
                    <?php if ($r['status'] === 'pending'): ?>
                      <form method="POST" style="display:inline" onsubmit="return confirm('Cancel this request?')">
                        <input type="hidden" name="action" value="delete"/>
                        <input type="hidden" name="id" value="<?= $r['id'] ?>"/>
                        <button type="submit" class="act-btn act-block"><?= icon('x', 13) ?> Cancel</button>
                      </form>
                    <?php else: ?>
                      <span style="color:var(--text-muted);font-size:12px">—</span>
                    <?php endif; ?>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php if (!$is_reviewer && $my_employee): ?>
<!-- File request modal (requesters only) -->
<div class="modal-overlay" id="file-modal" onclick="if(event.target===this) closeFile()">
  <div class="modal">
    <div class="modal-header">
      <h3><?= icon('plus', 18) ?> New Request</h3>
      <button class="modal-close" onclick="closeFile()"><?= icon('x', 16) ?></button>
    </div>
    <form method="POST" id="hr-request-form">
      <input type="hidden" name="action" value="file"/>

      <div class="field-group mg-b">
        <label class="field-label">Filing as</label>
        <input class="field-input" type="text" value="<?= htmlspecialchars($my_employee['firstname'].' '.$my_employee['lastname'].' (#'.$my_employee['employee_code'].')') ?>" disabled/>
      </div>

      <div class="field-group mg-b">
        <label class="field-label">Request Type <span class="req">*</span></label>
        <select class="field-input" name="request_type" id="hr-request-type" required>
          <option value="">Select a request type…</option>
          <?php foreach ($request_types as $t): ?><option value="<?= $t ?>"><?= $t ?></option><?php endforeach; ?>
        </select>
      </div>

      <div class="field-group mg-b">
        <label class="field-label">Details / Notes</label>
        <textarea class="field-input" name="details" id="hr-details" rows="3" placeholder="Provide any additional context or details for HR"></textarea>
      </div>

      <div class="modal-actions">
        <button type="button" class="btn-cancel" onclick="closeFile()">Cancel</button>
        <button type="submit" class="btn-save" id="hr-submit-btn"><?= icon('check', 14) ?> Submit Request</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php if ($toast): ?>
<div class="toast toast-<?= $toast_type ?>" id="toast-msg"><?= $toast ?></div>
<script>setTimeout(()=>{const t=document.getElementById('toast-msg'); if(t) t.style.opacity='0';},3500);</script>
<?php endif; ?>

<script src="../js/validator.js"></script>
<script>
function openFile()  { document.getElementById('file-modal')?.classList.add('open'); }
function closeFile() {
  const modal = document.getElementById('file-modal');
  if (modal) {
    modal.classList.remove('open');
    if (window.KofeeValidator) {
      document.querySelectorAll('#hr-request-form input, #hr-request-form select, #hr-request-form textarea').forEach(el => {
        KofeeValidator.clearError(el);
      });
    }
  }
}

const hrForm = document.getElementById('hr-request-form');
if (hrForm && window.KofeeValidator) {
  KofeeValidator.attach(hrForm, {
    customValidate: function(form) {
      const typeSel = form.querySelector('[name="request_type"]');
      const details = form.querySelector('[name="details"]');
      if (!typeSel.value) {
        return { field: typeSel, message: 'Please select a request type.' };
      }
      if (typeSel.value === 'Other' && (!details.value.trim() || details.value.trim().length < 5)) {
        return { field: details, message: 'Please explain your request in the details field (at least 5 characters).' };
      }
      return true;
    },
    loadingText: 'Submitting…'
  });
}

// Add loading indicators on review actions
document.querySelectorAll('.data-table form').forEach(f => {
  f.addEventListener('submit', function() {
    const btn = f.querySelector('button[type="submit"]');
    if (btn && window.KofeeValidator) {
      KofeeValidator.setLoading(btn, '…');
    }
  });
});

document.addEventListener('keydown', e => { if (e.key === 'Escape') closeFile(); });
</script>

</body>
</html>